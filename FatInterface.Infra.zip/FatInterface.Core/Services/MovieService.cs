﻿using FatInterface.Core.Entities;
using FatInterface.Core.Interfaces.Services;

namespace FatInterface.Core.Services
{
    public class MovieService : GenericService<Movie>, IMovieService
    {

    }
}
