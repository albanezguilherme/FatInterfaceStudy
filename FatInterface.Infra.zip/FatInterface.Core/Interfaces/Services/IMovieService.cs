﻿using FatInterface.Core.Entities;

namespace FatInterface.Core.Interfaces.Services
{
    public interface IMovieService : IGenericService<Movie>
    {
    }
}
