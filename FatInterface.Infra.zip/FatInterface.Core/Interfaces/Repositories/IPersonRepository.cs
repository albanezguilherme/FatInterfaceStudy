﻿using FatInterface.Core.Entities;

namespace FatInterface.Core.Interfaces.Repositories
{
    public interface IPersonRepository : IGenericRepository<Person>
    {
    }
}
