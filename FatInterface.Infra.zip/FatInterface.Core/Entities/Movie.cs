﻿namespace FatInterface.Core.Entities
{
    public class Movie
    {
    }
}
